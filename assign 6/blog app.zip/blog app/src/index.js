const app = require('./app');
const dotenv = require('dotenv');

const mongoose = require('mongoose');
// const Blog = require("../src/models/Blog") //scehema 


dotenv.config();

//connect to DB
mongoose.connect(process.env.DATABASE_URL,{ useNewUrlParser: true, useUnifiedTopology: true }, () => {
    console.log('connected to DB')
})



// console.log(app)
// console.log(mongoose.connection)
app.listen(3000, () => console.log('Server running......'));

