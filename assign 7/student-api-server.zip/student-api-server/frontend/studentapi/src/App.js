import './App.css';
import Home from './Layout/Home';
function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
