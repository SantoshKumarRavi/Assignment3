const fs = require("fs/promises");

const myFileWriter = async (fileName, fileContent) => {
  await fs
    .writeFile(fileName, fileContent, "utf-8", { flag: "a+" }, (err) => {
      console.log(err);
    })
    .then(myFileReader(fileName));
};

const myFileReader = async (fileName) => {
  await fs
    .readFile(fileName, "utf-8", (err, data) => {
      if (err) {
        console.log("err ", err);
      }
    })
    .then((data) => {
      console.log(data);
    });
};

const myFileUpdater = async (fileName, fileContent) => {
  await fs
    .appendFile(fileName, fileContent, "utf-8", { flag: "a+" }, (err) => {
      if (err) {
        console.log(err);
        return;
      }
    })
    .then(
      myFileReader(fileName)
    );
};

const myFileDeleter = async (fileName) => {
  await fs.rm(fileName);
};

// //Execute  one by one by Commenting remaining function Call to display the proper Output

// // parameters ===> (filename, content)

// // 1)writing new files and showiung
 myFileWriter("new66.txt","hello ")


  // // //2) reading values
 myFileReader("new66.txt")


  // // //3)updaing and reading the updated values
  myFileUpdater("new66.txt", " world ")


  // // //4)delete Files
  myFileDeleter("new66.txt")


module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter };
