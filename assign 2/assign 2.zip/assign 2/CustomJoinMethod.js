function JoinString(){
return Object.defineProperties(String.prototype, {
  my: {
    get: function () {
      //it stores string value that is calling functions
      const thisString = this;

      const myStringFunctions = {
        //use get if you want to return a value without parenthesis ()
        get len() {
          return thisString.length;
        },
        upp: function (array) {
          return (thisString.toString().toUpperCase()+" "+array.join(" "));
        },
      };

      return myStringFunctions;
    },
  },
});
}
module.exports=JoinString