process.env.USERNAME="Santhosh" 


console.log("Hello "+process.env.USERNAME)
