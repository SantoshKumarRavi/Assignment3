let JoinString = require('./CustomJoinMethod');
JoinString()

const process = require('process');
process.argv.splice(0,2)

console.log("hello".my.upp(process.argv))
